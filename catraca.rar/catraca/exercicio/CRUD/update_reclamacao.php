<?php
    require('../conn.php');

    $id_reclamacao = $_POST['id_reclamacao'];
    $reclamacao = $_POST['reclamacao'];
    $nome_reclamacao =$_POST['nome_reclamacao'];

    if(empty($nome_reclamacao) || empty($reclamacao)){
        echo "Os valores não podem ser vazios";
    }else{
        $update_reclamacao = $pdo->prepare("UPDATE tb_reclamacao set 
        texto_reclamacao = :reclamacao, 
        nome_reclamacao = :nome_reclamacao WHERE 
        id_reclamacao = :id_reclamacao;");
    

    $update_reclamacao->execute(array(
        ':id_reclamacao' => $id_reclamacao,
        ':nome_reclamacao'=> $nome_reclamacao,
        ':reclamacao'=> $reclamacao
    ));

    echo "<script>
    alert('Reclamação Editada!');
    window.location.href='../tabela.php';
    </script>";
    }

?>