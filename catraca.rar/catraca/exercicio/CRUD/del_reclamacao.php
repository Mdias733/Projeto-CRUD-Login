<?php
    require('../conn.php');

   if( isset($_GET['reclamacao'])){
        $reclamacao = $_GET['reclamacao'];
   }else{
   }

   $del_prod = $pdo->prepare('DELETE FROM tb_reclamacao WHERE id_reclamacao=:reclamacao');
   $del_prod->execute(array(':reclamacao'=>$reclamacao));
   echo "<script>
   alert('Reclamação Editada!');
   window.location.href='../tabela.php';
   </script>";  
?>
