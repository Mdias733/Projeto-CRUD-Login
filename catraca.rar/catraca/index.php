<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="container">
		<div class="login">
			<h1>Login</h1>
			<form action="logar.php" method='post'>	
			<label for="user">Usuário:</label>
				<input type="text" id="user" name="user" placeholder="Digite seu usuário">
				<label for="password">Senha:</label>
				<input type="password" id="password" name="senha" placeholder="Digite sua senha">

				<input type="submit" value="Entrar">
			</form>
		</div>
	</div>
</body>
</html>