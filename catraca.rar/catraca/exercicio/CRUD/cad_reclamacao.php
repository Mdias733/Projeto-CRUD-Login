<?php
    require('../conn.php');

    $reclamacao = $_POST['reclamacao'];
    $nome_reclamacao =$_POST['nome_reclamacao'];

    if(empty($reclamacao)|| empty($nome_reclamacao)){
        echo "Nenhuma Reclamação foi criada";
        echo "<img src='https://neilpatel.com/wp-content/uploads/2019/05/ilustracao-sobre-o-error-404-not-found.jpeg' alt=''>";
    }else{
        $cad_reclamacao = $pdo->prepare("INSERT INTO tb_reclamacao (texto_reclamacao,nome_reclamacao) 
        VALUES(:reclamacao, :nome_reclamacao)");
        $cad_reclamacao->execute(array(
            ':reclamacao'=> $reclamacao,
            ':nome_reclamacao'=> $nome_reclamacao

        ));

        echo "<script>
        alert('Reclamação criada!');
        window.history.back();
        </script>";
    }
?>