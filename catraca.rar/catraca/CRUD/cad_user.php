<?php
    require('../conn.php');

    $cad_name = $_POST['cad_name'];
    $cad_DtNasc = $_POST['cad_DtNasc'];
    $cad_email = $_POST['cad_email'];
    $cad_senha = $_POST['cad_senha'];
   
    if(empty($cad_name) || empty($cad_DtNasc) || empty($cad_email) || empty($cad_senha)){
        echo "Os valores não podem ser vazios";
    }else{
        $check_user = $pdo->prepare("SELECT * FROM tb_cadUsuario WHERE nome_Usuario = :cad_name");
        $check_user->execute(array(':cad_name'=> $cad_name));
        $existing_user = $check_user->fetch();

        if ($existing_user) {
            echo "<script>
                alert('Usuário já Utilizado, por favor mude o Usuario!');
                window.history.back();
            </script>";
        } else {
            $cad_user = $pdo->prepare("INSERT INTO tb_cadUsuario(nome_Usuario, dtNasc_Usuario, email_Usuario, senha_Usuario) 
            VALUES(:cad_name, :cad_DtNasc, :cad_email, :cad_senha)");
            $cad_user->execute(array(
                ':cad_name'=> $cad_name,
                ':cad_DtNasc'=> $cad_DtNasc,
                ':cad_email'=> $cad_email,
                ':cad_senha'=> $cad_senha  
            ));

            echo "<script>
            alert('Cadastrado com Sucesso!');
            window.location.href='../index.php';
            </script>";
        }
    }
?>