<?php
  require("conn.php");

  $tabela = $pdo->prepare("SELECT nome_funcionario FROM tb_funcionarios;");
  $tabelaEntrada = $pdo->prepare("SELECT dataEHoraEntrada FROM tb_entradas;");
  $tabelaSaida = $pdo->prepare("SELECT dataEHorasaida FROM tb_saidas;");

  $tabelaFuncionario = $pdo->prepare("SELECT nome_funcionario FROM tb_funcionarios;");


  $tabela->execute();
  $tabelaEntrada->execute();
  $tabelaSaida->execute();

  $rowTabela = $tabela->fetchAll();
  $rowtabelaEntrada = $tabelaEntrada->fetchAll();
  $rowtabelaSaida = $tabelaSaida->fetchAll();


?>

 
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    
    <meta charset="UTF-8">
    <link rel="stylesheet" href="stylesADM.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details"><i></i>
      <span class="logo_name">Senai</span>
    </div>
      <ul class="nav-links">
        <li>
          <a href="painel.php" class="active">
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Painel Administrativo</span>
          </a>
        </li>
        <li>
          <a href="tabela.php">
            <i class='bx bx-box' ></i>
            <span class="links_name">Tabela</span>
          </a>
        </li>
       
        <li>
          <a href="#">
            <i class='bx bx-pie-chart-alt-2' ></i>
            <span class="links_name">Relatório</span>
          </a>
        </li>
        <li class="log_out">
          <a href="logout.php">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Log out</span>
          </a>
        </li>
      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard"></span><img src="https://static.portaldaindustria.com.br/media/uploads/logotipos/logo-senai.png" alt="" height="89" width="230">
      </div>
      <div class="box-search2">
        <input type="search" class="form-control" placeholder="Pesquisar" id="pesquisar">
        <button onclick="searchData()" class="btn btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
        </button>
    </div>
      <div class="profile-details">
        <span class="admin_name">Prem Shahi</span> 
        <i class='bx bx-chevron-down'  ></i> 
      </div>
    </nav>

    <div class="home-content">

      <div class="sales-boxes">
        <div class="recent-sales box">
          <div class="title">REGISTROS</div>
          <div class="sales-details">
            <ul class="details">
            <table class="table table-dark">
      <thead>
      <tr>
      <br>
      <th scope="col">Nomeㅤㅤㅤㅤㅤ</th>
      <th scope="col">Data e Hora Entradaㅤㅤㅤㅤㅤ</th>
      <th scope="col">Data e Hora Saídaㅤㅤㅤㅤㅤ</th>
      </tr>
      </thead>
      <tbody>
      <?php
      foreach($rowTabela as $linha){
      echo '<tr>';
      echo "<td>".$linha['nome_funcionario']."</td>";
      foreach($rowtabelaEntrada as $linha){
        echo "<td>".$linha['dataEHoraEntrada']."</td>";
      }
      foreach($rowtabelaSaida as $linha){
        echo "<td>".$linha['dataEHorasaida']."</td>";
      }
      echo '</tr>';
    }
    ?>
  </tbody>
  
  
</table>

          </ul>
          </div>
          <div class="button">
            <a href="tabela.php">See All</a>
          </div>
        </div>

        <div class="top-sales box">
          
        </div>
      </div>
    </div>
  </section>

  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

</body>
</html>

