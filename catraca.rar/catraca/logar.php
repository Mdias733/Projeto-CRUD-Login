<?php
    include("conn.php");
    $login = $_POST['user'];
    $senha = $_POST['senha'];

    $usuario = $pdo->prepare('SELECT * FROM tb_administradores where usuario_adm=:usuario_adm 
    AND senha_adm=:senha_adm');
    $usuario->execute(array(':usuario_adm'=>$login,':senha_adm'=>$senha));

    $rowTabela = $usuario->fetchAll();
    
    if (empty($rowTabela)){
        echo "<script>
        alert('Usuario e/ou senha invalidos!!!');
        </script>";
    }else{
       
    $sessao = $rowTabela[0];

    if(!isset($_SESSION)) {
    session_start();
    }
    $_SESSION['id_adm'] = $sessao['id_adm'];
    $_SESSION['usuario_adm'] = $sessao['usuario_adm'];

    header("Location: painel.php");
    }

?>
